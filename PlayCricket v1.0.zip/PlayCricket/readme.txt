Welcome to Play Cricket!
In this game, you have 30 balls to complete the given target. Use the following keys to operate the game:
• Press E to start the game by selecting your preferred language: E for English or H for Hindi.
• Press X to exit.
• Press A to play aggressively.
• Press B to check the current number of balls.
• Press S to play safely.
• Press C to check the current score.
If you have any questions or suggestions, connect with me on LinkedIn:

https://www.linkedin.com/in/neeraj-gupta-0991422a6?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app
© | Neeraj Gupta.